package com.centralcity.alquimia.domain;

import com.centralcity.alquimia.adapters.persistence.memory.InMemoryDeviceReportRepositoryAdapter;
import com.centralcity.alquimia.adapters.useCases.AlchemyUseCaseImpl;
import com.centralcity.alquimia.domain.exceptions.DeviceAlreadyRegisteredException;
import com.centralcity.alquimia.domain.exceptions.DeviceNotRegisteredException;
import com.centralcity.alquimia.domain.exceptions.InsufficientDataException;
import com.centralcity.alquimia.domain.exceptions.InvalidDistanceException;
import com.centralcity.alquimia.domain.exceptions.InvalidInformationException;
import com.centralcity.alquimia.domain.exceptions.InvalidMessageFragmentException;
import com.centralcity.alquimia.domain.exceptions.UnknownDeviceException;
import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.models.InterceptionResult;
import com.centralcity.alquimia.domain.ports.in.AlchemyInterceptionPort;
import com.centralcity.alquimia.domain.services.ConsultDeviceReportsService;
import com.centralcity.alquimia.domain.services.InterceptionAnalyzer;
import com.centralcity.alquimia.domain.services.LocationCalculator;
import com.centralcity.alquimia.domain.services.MessageReconstructor;
import com.centralcity.alquimia.domain.services.ProcessAccumulatedInformationService;
import com.centralcity.alquimia.domain.services.ProcessCompleteInformationService;
import com.centralcity.alquimia.domain.services.RegisterDeviceReportService;
import com.centralcity.alquimia.domain.services.RemoveDeviceReportService;
import com.centralcity.alquimia.domain.services.ReplaceDeviceReportService;
import com.centralcity.alquimia.domain.services.UpdateDeviceReportPartiallyService;
import com.centralcity.alquimia.domain.valueobjects.Distance;
import com.centralcity.alquimia.domain.valueobjects.MessageFragment;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/** Prueba F1-F6 contra el puerto de entrada con el adaptador en memoria, sin Spring ni HTTP. */
class AlchemyUseCaseTest {

    private static final double LAB_X = 100;
    private static final double LAB_Y = 200;

    private AlchemyInterceptionPort port;

    @BeforeEach
    void setUp() {
        InMemoryDeviceReportRepositoryAdapter repository = new InMemoryDeviceReportRepositoryAdapter();
        InterceptionAnalyzer analyzer = new InterceptionAnalyzer(new LocationCalculator(), new MessageReconstructor());
        port = new AlchemyUseCaseImpl(
                new ProcessCompleteInformationService(analyzer),
                new RegisterDeviceReportService(repository),
                new ConsultDeviceReportsService(repository),
                new ProcessAccumulatedInformationService(repository, analyzer),
                new ReplaceDeviceReportService(repository),
                new UpdateDeviceReportPartiallyService(repository),
                new RemoveDeviceReportService(repository));
    }

    private static double dist(SurveillanceDevice d) {
        return Math.hypot(LAB_X - d.position().x(), LAB_Y - d.position().y());
    }

    private static DeviceReport report(SurveillanceDevice d, String... words) {
        return new DeviceReport(d, new Distance(dist(d)), MessageFragment.of(List.of(words)));
    }

    private DeviceReport starLabs() {
        return report(SurveillanceDevice.STAR_LABS, "este", "", "un", "");
    }

    private DeviceReport ccpd() {
        return report(SurveillanceDevice.CCPD, "", "es", "", "mensaje");
    }

    private DeviceReport satellite() {
        return report(SurveillanceDevice.STAR_SATELLITE, "este", "", "", "mensaje");
    }

    private void registerAll() {
        port.register(satellite());
        port.register(starLabs());
        port.register(ccpd());
    }

    // F1
    @Test
    void f1_processesCompleteInformationWithoutStoringIt() {
        InterceptionResult result = port.processComplete(List.of(starLabs(), ccpd(), satellite()));
        assertEquals(LAB_X, result.location().x(), 0.01);
        assertEquals(LAB_Y, result.location().y(), 0.01);
        assertEquals("este es un mensaje", result.message());
        assertEquals(0, port.consultAll().size());
    }

    @Test
    void f1_rejectsRepeatedOrMissingDevices() {
        assertThrows(InvalidInformationException.class, () -> port.processComplete(List.of(starLabs(), starLabs(), ccpd())));
        assertThrows(InvalidInformationException.class, () -> port.processComplete(List.of(starLabs(), ccpd())));
    }

    // F2 + F3
    @Test
    void f2f3_registersInAnyOrderAndProcessesAccumulated() {
        registerAll();
        assertEquals(3, port.consultAll().size());
        InterceptionResult result = port.processAccumulated();
        assertEquals(LAB_X, result.location().x(), 0.01);
        assertEquals("este es un mensaje", result.message());
    }

    @Test
    void f3_reportsInsufficientDataUntilTheThreeDevicesArrive() {
        port.register(starLabs());
        port.register(ccpd());
        assertThrows(InsufficientDataException.class, () -> port.processAccumulated());
        port.register(satellite());
        assertEquals("este es un mensaje", port.processAccumulated().message());
    }

    @Test
    void f2_rejectsDuplicateRegistrationAndInvalidData() {
        port.register(starLabs());
        assertThrows(DeviceAlreadyRegisteredException.class, () -> port.register(starLabs()));
        assertThrows(InvalidDistanceException.class, () -> new Distance(-1));
        assertThrows(InvalidMessageFragmentException.class, () -> MessageFragment.of(List.of()));
        assertThrows(UnknownDeviceException.class, () -> SurveillanceDevice.fromCode("batcave"));
    }

    @Test
    void f3_consultOfAnUnregisteredDeviceFails() {
        assertThrows(DeviceNotRegisteredException.class, () -> port.consult(SurveillanceDevice.CCPD));
    }

    // F4
    @Test
    void f4_replaceSubstitutesEverythingOfOneDeviceOnly() {
        registerAll();
        DeviceReport replacement = new DeviceReport(SurveillanceDevice.CCPD, new Distance(dist(SurveillanceDevice.CCPD)),
                MessageFragment.of(List.of("", "es", "un", "")));
        port.replace(replacement);

        assertEquals(replacement, port.consult(SurveillanceDevice.CCPD));
        assertEquals(starLabs(), port.consult(SurveillanceDevice.STAR_LABS));
        assertEquals(satellite(), port.consult(SurveillanceDevice.STAR_SATELLITE));
    }

    @Test
    void f4_replaceOfAnUnregisteredDeviceFails() {
        assertThrows(DeviceNotRegisteredException.class, () -> port.replace(ccpd()));
    }

    // F5
    @Test
    void f5_partialUpdateOfDistanceKeepsTheFragment() {
        registerAll();
        port.updatePartially(SurveillanceDevice.CCPD, new Distance(123.5), null);
        DeviceReport updated = port.consult(SurveillanceDevice.CCPD);
        assertEquals(123.5, updated.distance().value(), 0.0);
        assertEquals(ccpd().fragment(), updated.fragment());
    }

    @Test
    void f5_partialUpdateOfFragmentKeepsTheDistance() {
        registerAll();
        MessageFragment newFragment = MessageFragment.of(List.of("", "es", "un", "mensaje"));
        port.updatePartially(SurveillanceDevice.CCPD, null, newFragment);
        DeviceReport updated = port.consult(SurveillanceDevice.CCPD);
        assertEquals(newFragment, updated.fragment());
        assertEquals(ccpd().distance(), updated.distance());
    }

    @Test
    void f5_partialUpdateOfBothAndDoesNotTouchOtherDevices() {
        registerAll();
        port.updatePartially(SurveillanceDevice.STAR_LABS, new Distance(1), MessageFragment.of(List.of("a")));
        assertEquals(ccpd(), port.consult(SurveillanceDevice.CCPD));
        assertEquals(satellite(), port.consult(SurveillanceDevice.STAR_SATELLITE));
    }

    @Test
    void f5_partialUpdateNeedsAtLeastOneFieldAndARegisteredDevice() {
        registerAll();
        assertThrows(InvalidInformationException.class, () -> port.updatePartially(SurveillanceDevice.CCPD, null, null));
        port.remove(SurveillanceDevice.CCPD);
        assertThrows(DeviceNotRegisteredException.class,
                () -> port.updatePartially(SurveillanceDevice.CCPD, new Distance(5), null));
    }

    // F6
    @Test
    void f6_removeDeletesOnlyThatDevice() {
        registerAll();
        port.remove(SurveillanceDevice.CCPD);
        assertEquals(2, port.consultAll().size());
        assertThrows(DeviceNotRegisteredException.class, () -> port.consult(SurveillanceDevice.CCPD));
        assertThrows(InsufficientDataException.class, () -> port.processAccumulated());
        assertThrows(DeviceNotRegisteredException.class, () -> port.remove(SurveillanceDevice.CCPD));
    }

    @Test
    void f6_aRemovedDeviceCanBeRegisteredAgain() {
        registerAll();
        port.remove(SurveillanceDevice.CCPD);
        port.register(ccpd());
        assertEquals("este es un mensaje", port.processAccumulated().message());
    }
}
