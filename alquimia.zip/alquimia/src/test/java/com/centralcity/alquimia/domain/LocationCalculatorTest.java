package com.centralcity.alquimia.domain;

import com.centralcity.alquimia.domain.exceptions.InconsistentDataException;
import com.centralcity.alquimia.domain.services.LocationCalculator;
import com.centralcity.alquimia.domain.valueobjects.Distance;
import com.centralcity.alquimia.domain.valueobjects.Position;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;
import org.junit.jupiter.api.Test;

import java.util.EnumMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class LocationCalculatorTest {

    private final LocationCalculator calculator = new LocationCalculator();

    private static Map<SurveillanceDevice, Distance> distancesTo(double x, double y) {
        Map<SurveillanceDevice, Distance> map = new EnumMap<>(SurveillanceDevice.class);
        for (SurveillanceDevice device : SurveillanceDevice.values()) {
            map.put(device, new Distance(Math.hypot(x - device.position().x(), y - device.position().y())));
        }
        return map;
    }

    @Test
    void locatesThePointFromExactDistances() {
        Position p = calculator.locate(distancesTo(100, 200));
        assertEquals(100.0, p.x(), 0.01);
        assertEquals(200.0, p.y(), 0.01);
    }

    @Test
    void locatesNegativeCoordinates() {
        Position p = calculator.locate(distancesTo(-123.45, -67.89));
        assertEquals(-123.45, p.x(), 0.01);
        assertEquals(-67.89, p.y(), 0.01);
    }

    @Test
    void rejectsInconsistentDistances() {
        Map<SurveillanceDevice, Distance> map = distancesTo(100, 200);
        map.put(SurveillanceDevice.CCPD, new Distance(5));
        assertThrows(InconsistentDataException.class, () -> calculator.locate(map));
    }
}
