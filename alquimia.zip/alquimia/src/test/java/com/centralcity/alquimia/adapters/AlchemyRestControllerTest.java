package com.centralcity.alquimia.adapters;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.closeTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** Recorre F1-F6 por HTTP. Lab en (100, 200): distancias 721.11, 300 y 412.31. */
@SpringBootTest
@AutoConfigureMockMvc
class AlchemyRestControllerTest {

    @Autowired
    private MockMvc mvc;

    private static final String STAR_LABS = "{\"deviceId\":\"star-labs\",\"distance\":721.11,\"message\":[\"este\",\"\",\"un\",\"\"]}";
    private static final String CCPD = "{\"deviceId\":\"ccpd\",\"distance\":300,\"message\":[\"\",\"es\",\"\",\"mensaje\"]}";
    private static final String SATELLITE = "{\"deviceId\":\"star-satellite\",\"distance\":412.31,\"message\":[\"este\",\"\",\"\",\"mensaje\"]}";

    @BeforeEach
    void clean() throws Exception {
        for (String id : new String[] {"star-labs", "ccpd", "star-satellite"}) {
            mvc.perform(delete("/api/alchemy/devices/" + id)); // 204 o 404, da igual
        }
    }

    private void postJson(String path, String json, int expected) throws Exception {
        mvc.perform(post(path).contentType(MediaType.APPLICATION_JSON).content(json)).andExpect(status().is(expected));
    }

    private void registerAll() throws Exception {
        postJson("/api/alchemy/devices", SATELLITE, 201);
        postJson("/api/alchemy/devices", STAR_LABS, 201);
        postJson("/api/alchemy/devices", CCPD, 201);
    }

    @Test
    void f1_processComplete() throws Exception {
        String body = "{\"devices\":[" + STAR_LABS + "," + CCPD + "," + SATELLITE + "]}";
        mvc.perform(post("/api/alchemy/process").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.location.x").value(closeTo(100.0, 0.5)))
                .andExpect(jsonPath("$.location.y").value(closeTo(200.0, 0.5)))
                .andExpect(jsonPath("$.message").value("este es un mensaje"));
    }

    @Test
    void f1_rejectsAnIncompleteRequest() throws Exception {
        postJson("/api/alchemy/process", "{\"devices\":[" + STAR_LABS + "]}", 400);
    }

    @Test
    void f2f3_registerThenProcessAccumulated() throws Exception {
        postJson("/api/alchemy/devices", STAR_LABS, 201);
        mvc.perform(get("/api/alchemy/result")).andExpect(status().isUnprocessableEntity())
                .andExpect(jsonPath("$.code").value("INSUFFICIENT_DATA"));
        postJson("/api/alchemy/devices", CCPD, 201);
        postJson("/api/alchemy/devices", SATELLITE, 201);
        mvc.perform(get("/api/alchemy/devices")).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(3));
        mvc.perform(get("/api/alchemy/result")).andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("este es un mensaje"));
    }

    @Test
    void f2_validations() throws Exception {
        postJson("/api/alchemy/devices", "{\"deviceId\":\"batcave\",\"distance\":1,\"message\":[\"a\"]}", 404);
        postJson("/api/alchemy/devices", "{\"deviceId\":\"ccpd\",\"distance\":-5,\"message\":[\"a\"]}", 400);
        postJson("/api/alchemy/devices", "{\"deviceId\":\"ccpd\",\"message\":[\"a\"]}", 400);
        postJson("/api/alchemy/devices", "{\"deviceId\":\"ccpd\",\"distance\":1,\"message\":[]}", 400);
        postJson("/api/alchemy/devices", "esto no es json", 400);
        postJson("/api/alchemy/devices", CCPD, 201);
        postJson("/api/alchemy/devices", CCPD, 409);
    }

    @Test
    void f4_replace() throws Exception {
        registerAll();
        mvc.perform(put("/api/alchemy/devices/ccpd").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"distance\":300,\"message\":[\"\",\"es\",\"un\",\"\"]}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.message[2]").value("un"));
        mvc.perform(get("/api/alchemy/devices/star-labs")).andExpect(jsonPath("$.distance").value(721.11));
        mvc.perform(put("/api/alchemy/devices/ccpd").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"distance\":300}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void f5_partialUpdate() throws Exception {
        registerAll();
        mvc.perform(patch("/api/alchemy/devices/ccpd").contentType(MediaType.APPLICATION_JSON).content("{\"distance\":250}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.distance").value(250.0))
                .andExpect(jsonPath("$.message[1]").value("es"));
        mvc.perform(patch("/api/alchemy/devices/ccpd").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void f6_delete() throws Exception {
        registerAll();
        mvc.perform(delete("/api/alchemy/devices/ccpd")).andExpect(status().isNoContent());
        mvc.perform(get("/api/alchemy/devices/ccpd")).andExpect(status().isNotFound());
        mvc.perform(get("/api/alchemy/devices/star-labs")).andExpect(status().isOk());
        mvc.perform(delete("/api/alchemy/devices/ccpd")).andExpect(status().isNotFound());
    }
}
