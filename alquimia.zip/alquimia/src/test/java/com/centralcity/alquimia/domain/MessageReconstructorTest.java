package com.centralcity.alquimia.domain;

import com.centralcity.alquimia.domain.exceptions.InconsistentDataException;
import com.centralcity.alquimia.domain.exceptions.InsufficientDataException;
import com.centralcity.alquimia.domain.services.MessageReconstructor;
import com.centralcity.alquimia.domain.valueobjects.MessageFragment;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class MessageReconstructorTest {

    private final MessageReconstructor reconstructor = new MessageReconstructor();

    private static MessageFragment f(String... words) {
        return MessageFragment.of(List.of(words));
    }

    @Test
    void mergesFragmentsIgnoringEmptyWords() {
        String message = reconstructor.reconstruct(List.of(
                f("este", "", "un", ""),
                f("", "es", "", "mensaje"),
                f("este", "", "", "mensaje")));
        assertEquals("este es un mensaje", message);
    }

    @Test
    void failsWhenAPositionWasReceivedByNobody() {
        assertThrows(InsufficientDataException.class, () -> reconstructor.reconstruct(List.of(
                f("este", "", "un"), f("", "", "un"), f("este", "", ""))));
    }

    @Test
    void failsWhenDevicesDisagreeOnAWord() {
        assertThrows(InconsistentDataException.class, () -> reconstructor.reconstruct(List.of(
                f("hola", "mundo"), f("hola", "tierra"), f("", ""))));
    }

    @Test
    void failsWhenFragmentsHaveDifferentLengths() {
        assertThrows(InconsistentDataException.class, () -> reconstructor.reconstruct(List.of(
                f("hola", "mundo"), f("hola"), f("hola", "mundo"))));
    }
}
