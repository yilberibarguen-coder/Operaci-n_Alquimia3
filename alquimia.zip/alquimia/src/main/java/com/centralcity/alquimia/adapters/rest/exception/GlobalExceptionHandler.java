package com.centralcity.alquimia.adapters.rest.exception;

import com.centralcity.alquimia.adapters.rest.dtos.responses.ErrorResponseDTO;
import com.centralcity.alquimia.domain.exceptions.DeviceAlreadyRegisteredException;
import com.centralcity.alquimia.domain.exceptions.DeviceNotRegisteredException;
import com.centralcity.alquimia.domain.exceptions.DomainException;
import com.centralcity.alquimia.domain.exceptions.InconsistentDataException;
import com.centralcity.alquimia.domain.exceptions.InsufficientDataException;
import com.centralcity.alquimia.domain.exceptions.UnknownDeviceException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.stream.Collectors;

/** Traduce los errores del dominio a respuestas HTTP con un cuerpo uniforme. */
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler({UnknownDeviceException.class, DeviceNotRegisteredException.class})
    public ResponseEntity<ErrorResponseDTO> handleNotFound(DomainException ex) {
        return body(HttpStatus.NOT_FOUND, ex.getCode(), ex.getMessage());
    }

    @ExceptionHandler(DeviceAlreadyRegisteredException.class)
    public ResponseEntity<ErrorResponseDTO> handleConflict(DomainException ex) {
        return body(HttpStatus.CONFLICT, ex.getCode(), ex.getMessage());
    }

    /** La peticion es valida pero la informacion disponible no permite calcular. */
    @ExceptionHandler({InsufficientDataException.class, InconsistentDataException.class})
    public ResponseEntity<ErrorResponseDTO> handleUnprocessable(DomainException ex) {
        return body(HttpStatus.UNPROCESSABLE_ENTITY, ex.getCode(), ex.getMessage());
    }

    @ExceptionHandler(DomainException.class)
    public ResponseEntity<ErrorResponseDTO> handleDomain(DomainException ex) {
        return body(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponseDTO> handleValidation(MethodArgumentNotValidException ex) {
        String message = ex.getBindingResult().getFieldErrors().stream()
                .map(e -> e.getField() + ": " + e.getDefaultMessage())
                .sorted()
                .collect(Collectors.joining("; "));
        return body(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", message.isBlank() ? "Peticion invalida." : message);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponseDTO> handleUnreadable(HttpMessageNotReadableException ex) {
        return body(HttpStatus.BAD_REQUEST, "MALFORMED_REQUEST", "El cuerpo de la peticion no es un JSON valido.");
    }

    private ResponseEntity<ErrorResponseDTO> body(HttpStatus status, String code, String message) {
        return ResponseEntity.status(status).body(new ErrorResponseDTO(Instant.now(), status.value(), code, message));
    }
}
