package com.centralcity.alquimia.domain.services;

import com.centralcity.alquimia.domain.ports.out.DeviceReportRepositoryPort;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;

/** F6: elimina la informacion de un dispositivo sin afectar a los demas. */
public class RemoveDeviceReportService {

    private final DeviceReportRepositoryPort repository;

    public RemoveDeviceReportService(DeviceReportRepositoryPort repository) {
        this.repository = repository;
    }

    public void remove(SurveillanceDevice device) {
        if (!repository.existsByDevice(device)) {
            throw ConsultDeviceReportsService.notRegistered(device);
        }
        repository.deleteByDevice(device);
    }
}
