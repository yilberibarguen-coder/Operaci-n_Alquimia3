package com.centralcity.alquimia.adapters.rest.mappers;

import com.centralcity.alquimia.adapters.rest.dtos.requests.DeviceDataRequestDTO;
import com.centralcity.alquimia.adapters.rest.dtos.requests.DeviceReadingRequestDTO;
import com.centralcity.alquimia.adapters.rest.dtos.responses.DeviceReportResponseDTO;
import com.centralcity.alquimia.adapters.rest.dtos.responses.ResultResponseDTO;
import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.models.InterceptionResult;
import com.centralcity.alquimia.domain.valueobjects.Distance;
import com.centralcity.alquimia.domain.valueobjects.MessageFragment;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;

import java.util.List;

/** Traduce entre DTOs (HTTP) y tipos del dominio. El dominio nunca ve un DTO. */
public final class AlchemyRestMapper {

    private AlchemyRestMapper() {
    }

    public static DeviceReport toDomain(DeviceReadingRequestDTO dto) {
        return new DeviceReport(SurveillanceDevice.fromCode(dto.deviceId()),
                new Distance(dto.distance()), MessageFragment.of(dto.message()));
    }

    public static DeviceReport toDomain(SurveillanceDevice device, DeviceDataRequestDTO dto) {
        return new DeviceReport(device, new Distance(dto.distance()), MessageFragment.of(dto.message()));
    }

    /** Devuelve null si el campo no llego (para la actualizacion parcial). */
    public static Distance toDistance(Double value) {
        return value == null ? null : new Distance(value);
    }

    /** Devuelve null si el campo no llego (para la actualizacion parcial). */
    public static MessageFragment toFragment(List<String> words) {
        return words == null ? null : MessageFragment.of(words);
    }

    public static DeviceReportResponseDTO toResponse(DeviceReport report) {
        return new DeviceReportResponseDTO(report.device().code(), report.device().displayName(),
                report.distance().value(), report.fragment().words());
    }

    public static ResultResponseDTO toResponse(InterceptionResult result) {
        return new ResultResponseDTO(
                new ResultResponseDTO.LocationDTO(result.location().x(), result.location().y()), result.message());
    }
}
