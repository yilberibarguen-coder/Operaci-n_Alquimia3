package com.centralcity.alquimia.domain.valueobjects;

import com.centralcity.alquimia.domain.exceptions.UnknownDeviceException;

import java.util.Arrays;
import java.util.Locale;

/** Catalogo cerrado de dispositivos de vigilancia con su posicion fija. */
public enum SurveillanceDevice {

    STAR_LABS("star-labs", "STAR Labs", new Position(-500, -200)),
    CCPD("ccpd", "CCPD", new Position(100, -100)),
    STAR_SATELLITE("star-satellite", "S.T.A.R. Satellite", new Position(500, 100));

    private final String code;
    private final String displayName;
    private final Position position;

    SurveillanceDevice(String code, String displayName, Position position) {
        this.code = code;
        this.displayName = displayName;
        this.position = position;
    }

    public String code() {
        return code;
    }

    public String displayName() {
        return displayName;
    }

    public Position position() {
        return position;
    }

    public static SurveillanceDevice fromCode(String code) {
        if (code != null) {
            String normalized = code.strip().toLowerCase(Locale.ROOT);
            for (SurveillanceDevice device : values()) {
                if (device.code.equals(normalized)) {
                    return device;
                }
            }
        }
        throw new UnknownDeviceException("Dispositivo desconocido: '" + code + "'. Validos: "
                + Arrays.stream(values()).map(SurveillanceDevice::code).toList());
    }
}
