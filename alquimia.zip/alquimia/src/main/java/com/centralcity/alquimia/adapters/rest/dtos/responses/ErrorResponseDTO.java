package com.centralcity.alquimia.adapters.rest.dtos.responses;

import java.time.Instant;

public record ErrorResponseDTO(Instant timestamp, int status, String code, String message) {
}
