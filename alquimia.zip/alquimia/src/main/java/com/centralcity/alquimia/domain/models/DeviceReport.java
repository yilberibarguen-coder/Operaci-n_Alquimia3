package com.centralcity.alquimia.domain.models;

import com.centralcity.alquimia.domain.valueobjects.Distance;
import com.centralcity.alquimia.domain.valueobjects.MessageFragment;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;

import java.util.Objects;

/** Informacion registrada de un dispositivo (identidad = dispositivo). Inmutable: cada cambio crea una nueva instancia. */
public record DeviceReport(SurveillanceDevice device, Distance distance, MessageFragment fragment) {

    public DeviceReport {
        Objects.requireNonNull(device, "device");
        Objects.requireNonNull(distance, "distance");
        Objects.requireNonNull(fragment, "fragment");
    }

    /** Actualizacion parcial: solo cambia lo que llega (no nulo); lo demas conserva su valor anterior. */
    public DeviceReport partiallyUpdatedWith(Distance newDistance, MessageFragment newFragment) {
        return new DeviceReport(device,
                newDistance != null ? newDistance : distance,
                newFragment != null ? newFragment : fragment);
    }
}
