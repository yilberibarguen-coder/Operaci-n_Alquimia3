package com.centralcity.alquimia.adapters.useCases;

import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.models.InterceptionResult;
import com.centralcity.alquimia.domain.ports.in.AlchemyInterceptionPort;
import com.centralcity.alquimia.domain.services.ConsultDeviceReportsService;
import com.centralcity.alquimia.domain.services.ProcessAccumulatedInformationService;
import com.centralcity.alquimia.domain.services.ProcessCompleteInformationService;
import com.centralcity.alquimia.domain.services.RegisterDeviceReportService;
import com.centralcity.alquimia.domain.services.RemoveDeviceReportService;
import com.centralcity.alquimia.domain.services.ReplaceDeviceReportService;
import com.centralcity.alquimia.domain.services.UpdateDeviceReportPartiallyService;
import com.centralcity.alquimia.domain.valueobjects.Distance;
import com.centralcity.alquimia.domain.valueobjects.MessageFragment;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Implementa el puerto de entrada delegando en los servicios del dominio.
 * Los metodos son synchronized: como el estado vive en memoria de un solo proceso, esto vuelve atomicas las
 * operaciones de leer-y-escribir (registro, reemplazo, actualizacion parcial, eliminacion y procesamiento).
 */
@Service
public class AlchemyUseCaseImpl implements AlchemyInterceptionPort {

    private final ProcessCompleteInformationService processComplete;
    private final RegisterDeviceReportService register;
    private final ConsultDeviceReportsService consult;
    private final ProcessAccumulatedInformationService processAccumulated;
    private final ReplaceDeviceReportService replace;
    private final UpdateDeviceReportPartiallyService updatePartially;
    private final RemoveDeviceReportService remove;

    public AlchemyUseCaseImpl(ProcessCompleteInformationService processComplete,
                              RegisterDeviceReportService register,
                              ConsultDeviceReportsService consult,
                              ProcessAccumulatedInformationService processAccumulated,
                              ReplaceDeviceReportService replace,
                              UpdateDeviceReportPartiallyService updatePartially,
                              RemoveDeviceReportService remove) {
        this.processComplete = processComplete;
        this.register = register;
        this.consult = consult;
        this.processAccumulated = processAccumulated;
        this.replace = replace;
        this.updatePartially = updatePartially;
        this.remove = remove;
    }

    @Override
    public InterceptionResult processComplete(List<DeviceReport> reports) {
        return processComplete.process(reports);
    }

    @Override
    public synchronized DeviceReport register(DeviceReport report) {
        return register.register(report);
    }

    @Override
    public synchronized List<DeviceReport> consultAll() {
        return consult.consultAll();
    }

    @Override
    public synchronized DeviceReport consult(SurveillanceDevice device) {
        return consult.consult(device);
    }

    @Override
    public synchronized InterceptionResult processAccumulated() {
        return processAccumulated.process();
    }

    @Override
    public synchronized DeviceReport replace(DeviceReport newReport) {
        return replace.replace(newReport);
    }

    @Override
    public synchronized DeviceReport updatePartially(SurveillanceDevice device, Distance distance, MessageFragment fragment) {
        return updatePartially.update(device, distance, fragment);
    }

    @Override
    public synchronized void remove(SurveillanceDevice device) {
        remove.remove(device);
    }
}
