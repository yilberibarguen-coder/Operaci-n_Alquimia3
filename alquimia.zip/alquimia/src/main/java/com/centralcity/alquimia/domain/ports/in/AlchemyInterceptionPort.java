package com.centralcity.alquimia.domain.ports.in;

import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.models.InterceptionResult;
import com.centralcity.alquimia.domain.valueobjects.Distance;
import com.centralcity.alquimia.domain.valueobjects.MessageFragment;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;

import java.util.List;

/** Puerto de entrada: todo lo que el sistema ofrece a quien lo use (HTTP, consola, tests...). */
public interface AlchemyInterceptionPort {

    /** F1: procesa la informacion completa de los tres dispositivos sin almacenarla. */
    InterceptionResult processComplete(List<DeviceReport> reports);

    /** F2: registra la informacion de un dispositivo. */
    DeviceReport register(DeviceReport report);

    /** F3: consulta lo registrado. */
    List<DeviceReport> consultAll();

    DeviceReport consult(SurveillanceDevice device);

    /** F3: procesa lo acumulado; falla con "datos insuficientes" si no alcanza. */
    InterceptionResult processAccumulated();

    /** F4: reemplaza por completo la informacion de un dispositivo ya registrado. */
    DeviceReport replace(DeviceReport newReport);

    /** F5: actualiza distancia y/o fragmento (el que sea null conserva su valor). */
    DeviceReport updatePartially(SurveillanceDevice device, Distance distance, MessageFragment fragment);

    /** F6: elimina la informacion de un dispositivo. */
    void remove(SurveillanceDevice device);
}
