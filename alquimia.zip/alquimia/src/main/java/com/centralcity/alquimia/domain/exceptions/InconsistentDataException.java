package com.centralcity.alquimia.domain.exceptions;

public class InconsistentDataException extends DomainException {

    public InconsistentDataException(String message) {
        super("INCONSISTENT_DATA", message);
    }
}
