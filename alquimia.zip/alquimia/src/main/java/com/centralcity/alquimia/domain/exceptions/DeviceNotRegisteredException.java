package com.centralcity.alquimia.domain.exceptions;

public class DeviceNotRegisteredException extends DomainException {

    public DeviceNotRegisteredException(String message) {
        super("DEVICE_NOT_REGISTERED", message);
    }
}
