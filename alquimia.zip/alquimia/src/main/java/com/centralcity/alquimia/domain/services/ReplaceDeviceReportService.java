package com.centralcity.alquimia.domain.services;

import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.ports.out.DeviceReportRepositoryPort;

/** F4: sustituye por completo la informacion de un dispositivo; los demas no se tocan. */
public class ReplaceDeviceReportService {

    private final DeviceReportRepositoryPort repository;

    public ReplaceDeviceReportService(DeviceReportRepositoryPort repository) {
        this.repository = repository;
    }

    public DeviceReport replace(DeviceReport newReport) {
        if (!repository.existsByDevice(newReport.device())) {
            throw ConsultDeviceReportsService.notRegistered(newReport.device());
        }
        return repository.save(newReport);
    }
}
