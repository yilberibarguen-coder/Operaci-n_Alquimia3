package com.centralcity.alquimia.adapters.persistence.memory;

import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.ports.out.DeviceReportRepositoryPort;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentSkipListMap;

/** Adaptador de salida: guarda la informacion solo en memoria (se pierde al apagar la aplicacion). */
@Component
public class InMemoryDeviceReportRepositoryAdapter implements DeviceReportRepositoryPort {

    // Ordenado por el orden del enum, asi los listados son siempre deterministas.
    private final Map<SurveillanceDevice, DeviceReport> store = new ConcurrentSkipListMap<>();

    @Override
    public DeviceReport save(DeviceReport report) {
        store.put(report.device(), report);
        return report;
    }

    @Override
    public Optional<DeviceReport> findByDevice(SurveillanceDevice device) {
        return Optional.ofNullable(store.get(device));
    }

    @Override
    public List<DeviceReport> findAll() {
        return List.copyOf(store.values());
    }

    @Override
    public boolean existsByDevice(SurveillanceDevice device) {
        return store.containsKey(device);
    }

    @Override
    public void deleteByDevice(SurveillanceDevice device) {
        store.remove(device);
    }
}
