package com.centralcity.alquimia.domain.exceptions;

/** Base de todos los errores de negocio. Lleva un codigo estable para que los adaptadores lo traduzcan. */
public class DomainException extends RuntimeException {

    private final String code;

    public DomainException(String code, String message) {
        super(message);
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
