package com.centralcity.alquimia.domain.exceptions;

public class DeviceAlreadyRegisteredException extends DomainException {

    public DeviceAlreadyRegisteredException(String message) {
        super("DEVICE_ALREADY_REGISTERED", message);
    }
}
