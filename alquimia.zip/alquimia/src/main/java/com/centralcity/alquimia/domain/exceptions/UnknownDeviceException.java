package com.centralcity.alquimia.domain.exceptions;

public class UnknownDeviceException extends DomainException {

    public UnknownDeviceException(String message) {
        super("UNKNOWN_DEVICE", message);
    }
}
