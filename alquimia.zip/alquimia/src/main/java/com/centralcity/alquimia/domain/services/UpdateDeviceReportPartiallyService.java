package com.centralcity.alquimia.domain.services;

import com.centralcity.alquimia.domain.exceptions.InvalidInformationException;
import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.ports.out.DeviceReportRepositoryPort;
import com.centralcity.alquimia.domain.valueobjects.Distance;
import com.centralcity.alquimia.domain.valueobjects.MessageFragment;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;

/** F5: cambia solo lo recibido (distancia, fragmento o ambos) y conserva el resto. */
public class UpdateDeviceReportPartiallyService {

    private final DeviceReportRepositoryPort repository;

    public UpdateDeviceReportPartiallyService(DeviceReportRepositoryPort repository) {
        this.repository = repository;
    }

    public DeviceReport update(SurveillanceDevice device, Distance distance, MessageFragment fragment) {
        if (distance == null && fragment == null) {
            throw new InvalidInformationException("La actualizacion parcial requiere la distancia, el mensaje o ambos.");
        }
        DeviceReport current = repository.findByDevice(device)
                .orElseThrow(() -> ConsultDeviceReportsService.notRegistered(device));
        return repository.save(current.partiallyUpdatedWith(distance, fragment));
    }
}
