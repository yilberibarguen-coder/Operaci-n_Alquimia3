package com.centralcity.alquimia.domain.exceptions;

public class InvalidMessageFragmentException extends DomainException {

    public InvalidMessageFragmentException(String message) {
        super("INVALID_MESSAGE_FRAGMENT", message);
    }
}
