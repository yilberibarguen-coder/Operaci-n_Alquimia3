package com.centralcity.alquimia.infrastructure.config;

import com.centralcity.alquimia.domain.ports.out.DeviceReportRepositoryPort;
import com.centralcity.alquimia.domain.services.ConsultDeviceReportsService;
import com.centralcity.alquimia.domain.services.InterceptionAnalyzer;
import com.centralcity.alquimia.domain.services.LocationCalculator;
import com.centralcity.alquimia.domain.services.MessageReconstructor;
import com.centralcity.alquimia.domain.services.ProcessAccumulatedInformationService;
import com.centralcity.alquimia.domain.services.ProcessCompleteInformationService;
import com.centralcity.alquimia.domain.services.RegisterDeviceReportService;
import com.centralcity.alquimia.domain.services.RemoveDeviceReportService;
import com.centralcity.alquimia.domain.services.ReplaceDeviceReportService;
import com.centralcity.alquimia.domain.services.UpdateDeviceReportPartiallyService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Unico lugar donde Spring conoce los servicios del dominio: el dominio queda libre de anotaciones de framework. */
@Configuration
public class BeanConfiguration {

    @Bean
    public InterceptionAnalyzer interceptionAnalyzer() {
        return new InterceptionAnalyzer(new LocationCalculator(), new MessageReconstructor());
    }

    @Bean
    public ProcessCompleteInformationService processCompleteInformationService(InterceptionAnalyzer analyzer) {
        return new ProcessCompleteInformationService(analyzer);
    }

    @Bean
    public RegisterDeviceReportService registerDeviceReportService(DeviceReportRepositoryPort repository) {
        return new RegisterDeviceReportService(repository);
    }

    @Bean
    public ConsultDeviceReportsService consultDeviceReportsService(DeviceReportRepositoryPort repository) {
        return new ConsultDeviceReportsService(repository);
    }

    @Bean
    public ProcessAccumulatedInformationService processAccumulatedInformationService(
            DeviceReportRepositoryPort repository, InterceptionAnalyzer analyzer) {
        return new ProcessAccumulatedInformationService(repository, analyzer);
    }

    @Bean
    public ReplaceDeviceReportService replaceDeviceReportService(DeviceReportRepositoryPort repository) {
        return new ReplaceDeviceReportService(repository);
    }

    @Bean
    public UpdateDeviceReportPartiallyService updateDeviceReportPartiallyService(DeviceReportRepositoryPort repository) {
        return new UpdateDeviceReportPartiallyService(repository);
    }

    @Bean
    public RemoveDeviceReportService removeDeviceReportService(DeviceReportRepositoryPort repository) {
        return new RemoveDeviceReportService(repository);
    }
}
