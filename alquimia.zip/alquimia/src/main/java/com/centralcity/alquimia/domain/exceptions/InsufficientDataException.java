package com.centralcity.alquimia.domain.exceptions;

public class InsufficientDataException extends DomainException {

    public InsufficientDataException(String message) {
        super("INSUFFICIENT_DATA", message);
    }
}
