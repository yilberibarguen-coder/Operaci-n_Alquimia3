package com.centralcity.alquimia.adapters.rest.dtos.responses;

public record ResultResponseDTO(LocationDTO location, String message) {

    public record LocationDTO(double x, double y) {
    }
}
