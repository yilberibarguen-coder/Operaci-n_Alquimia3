package com.centralcity.alquimia.domain.valueobjects;

/** Punto (x, y) en el plano de Central City. */
public record Position(double x, double y) {

    public Position {
        if (!Double.isFinite(x) || !Double.isFinite(y)) {
            throw new IllegalArgumentException("Las coordenadas deben ser numeros finitos.");
        }
    }
}
