package com.centralcity.alquimia.domain.valueobjects;

import com.centralcity.alquimia.domain.exceptions.InvalidDistanceException;

/** Distancia desde un dispositivo hasta el laboratorio: numero finito y no negativo. */
public record Distance(double value) {

    public Distance {
        if (!Double.isFinite(value)) {
            throw new InvalidDistanceException("La distancia debe ser un numero finito.");
        }
        if (value < 0) {
            throw new InvalidDistanceException("La distancia no puede ser negativa: " + value);
        }
    }
}
