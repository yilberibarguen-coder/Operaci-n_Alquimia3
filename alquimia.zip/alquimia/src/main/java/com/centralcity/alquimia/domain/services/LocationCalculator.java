package com.centralcity.alquimia.domain.services;

import com.centralcity.alquimia.domain.exceptions.InconsistentDataException;
import com.centralcity.alquimia.domain.valueobjects.Distance;
import com.centralcity.alquimia.domain.valueobjects.Position;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;

import java.util.Map;

/** Trilateracion: resuelve el punto que esta a las tres distancias dadas de los tres dispositivos. */
public final class LocationCalculator {

    /** Margen (en unidades del plano) para tolerar distancias redondeadas. */
    static final double TOLERANCE = 1.0;
    private static final double EPSILON = 1e-9;

    public Position locate(Map<SurveillanceDevice, Distance> distances) {
        SurveillanceDevice[] devices = SurveillanceDevice.values();
        double[] x = new double[3];
        double[] y = new double[3];
        double[] d = new double[3];
        for (int i = 0; i < 3; i++) {
            Distance distance = distances.get(devices[i]);
            if (distance == null) {
                throw new IllegalStateException("Falta la distancia de " + devices[i]);
            }
            x[i] = devices[i].position().x();
            y[i] = devices[i].position().y();
            d[i] = distance.value();
        }

        // Restar la ecuacion del circulo 1 de la 2, y la 2 de la 3, elimina los cuadrados: queda un sistema lineal 2x2.
        double a = 2 * (x[1] - x[0]);
        double b = 2 * (y[1] - y[0]);
        double c = d[0] * d[0] - d[1] * d[1] + x[1] * x[1] - x[0] * x[0] + y[1] * y[1] - y[0] * y[0];
        double e = 2 * (x[2] - x[1]);
        double f = 2 * (y[2] - y[1]);
        double g = d[1] * d[1] - d[2] * d[2] + x[2] * x[2] - x[1] * x[1] + y[2] * y[2] - y[1] * y[1];

        double det = a * f - b * e;
        if (Math.abs(det) < EPSILON) {
            throw new InconsistentDataException("Los dispositivos son colineales: no se puede triangular la posicion.");
        }
        double px = (c * f - b * g) / det;
        double py = (a * g - c * e) / det;

        for (int i = 0; i < 3; i++) {
            double residual = Math.abs(Math.hypot(px - x[i], py - y[i]) - d[i]);
            if (residual > TOLERANCE) {
                throw new InconsistentDataException(
                        "Las distancias son inconsistentes: los tres circulos no se cruzan en un unico punto.");
            }
        }
        return new Position(round(px), round(py));
    }

    private static double round(double value) {
        return Math.round(value * 100.0) / 100.0 + 0.0; // + 0.0 evita -0.0
    }
}
