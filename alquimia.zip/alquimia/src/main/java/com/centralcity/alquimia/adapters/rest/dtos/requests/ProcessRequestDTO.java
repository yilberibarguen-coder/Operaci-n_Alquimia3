package com.centralcity.alquimia.adapters.rest.dtos.requests;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;

public record ProcessRequestDTO(
        @NotNull(message = "es obligatorio")
        @Size(min = 3, max = 3, message = "debe traer exactamente los 3 dispositivos")
        List<@NotNull(message = "no puede ser nulo") @Valid DeviceReadingRequestDTO> devices) {
}
