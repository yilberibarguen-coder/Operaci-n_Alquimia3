package com.centralcity.alquimia.domain.valueobjects;

import com.centralcity.alquimia.domain.exceptions.InvalidMessageFragmentException;

import java.util.List;

/**
 * Fragmento del mensaje interceptado por un dispositivo: una lista de palabras por posicion.
 * Una cadena vacia ("") significa que la palabra no fue recibida y se ignora al reconstruir.
 */
public record MessageFragment(List<String> words) {

    public MessageFragment {
        if (words == null || words.isEmpty()) {
            throw new InvalidMessageFragmentException("El fragmento debe tener al menos una posicion.");
        }
        for (String word : words) {
            if (word == null) {
                throw new InvalidMessageFragmentException(
                        "El fragmento no puede tener palabras nulas; use \"\" para una palabra no recibida.");
            }
        }
        words = words.stream().map(String::strip).toList();
    }

    public static MessageFragment of(List<String> words) {
        return new MessageFragment(words);
    }

    public int size() {
        return words.size();
    }
}
