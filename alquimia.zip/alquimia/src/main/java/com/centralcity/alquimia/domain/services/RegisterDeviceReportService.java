package com.centralcity.alquimia.domain.services;

import com.centralcity.alquimia.domain.exceptions.DeviceAlreadyRegisteredException;
import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.ports.out.DeviceReportRepositoryPort;

/** F2: registra un dispositivo. Si ya existe, hay que usar reemplazo o actualizacion parcial. */
public class RegisterDeviceReportService {

    private final DeviceReportRepositoryPort repository;

    public RegisterDeviceReportService(DeviceReportRepositoryPort repository) {
        this.repository = repository;
    }

    public DeviceReport register(DeviceReport report) {
        if (repository.existsByDevice(report.device())) {
            throw new DeviceAlreadyRegisteredException("El dispositivo '" + report.device().code()
                    + "' ya tiene informacion registrada; use reemplazo o actualizacion parcial.");
        }
        return repository.save(report);
    }
}
