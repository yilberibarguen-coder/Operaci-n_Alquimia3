package com.centralcity.alquimia.adapters.rest.dtos.responses;

import java.util.List;

public record DeviceReportResponseDTO(String deviceId, String deviceName, double distance, List<String> message) {
}
