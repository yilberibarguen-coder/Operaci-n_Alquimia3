package com.centralcity.alquimia.domain.exceptions;

public class InvalidInformationException extends DomainException {

    public InvalidInformationException(String message) {
        super("INVALID_INFORMATION", message);
    }
}
