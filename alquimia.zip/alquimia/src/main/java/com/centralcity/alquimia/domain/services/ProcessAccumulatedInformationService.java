package com.centralcity.alquimia.domain.services;

import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.models.InterceptionResult;
import com.centralcity.alquimia.domain.ports.out.DeviceReportRepositoryPort;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;

import java.util.EnumMap;
import java.util.Map;

/** F3 (procesamiento): usa lo acumulado; sin los tres dispositivos informa que no hay datos suficientes. */
public class ProcessAccumulatedInformationService {

    private final DeviceReportRepositoryPort repository;
    private final InterceptionAnalyzer analyzer;

    public ProcessAccumulatedInformationService(DeviceReportRepositoryPort repository, InterceptionAnalyzer analyzer) {
        this.repository = repository;
        this.analyzer = analyzer;
    }

    public InterceptionResult process() {
        Map<SurveillanceDevice, DeviceReport> byDevice = new EnumMap<>(SurveillanceDevice.class);
        for (DeviceReport report : repository.findAll()) {
            byDevice.put(report.device(), report);
        }
        return analyzer.analyze(byDevice);
    }
}
