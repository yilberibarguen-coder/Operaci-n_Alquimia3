package com.centralcity.alquimia.domain.exceptions;

public class InvalidDistanceException extends DomainException {

    public InvalidDistanceException(String message) {
        super("INVALID_DISTANCE", message);
    }
}
