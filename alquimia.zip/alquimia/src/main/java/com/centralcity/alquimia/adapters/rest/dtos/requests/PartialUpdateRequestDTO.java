package com.centralcity.alquimia.adapters.rest.dtos.requests;

import java.util.List;

/** Actualizacion parcial (F5): cada campo es opcional; lo que no llegue conserva su valor. */
public record PartialUpdateRequestDTO(Double distance, List<String> message) {
}
