package com.centralcity.alquimia.domain.services;

import com.centralcity.alquimia.domain.exceptions.InconsistentDataException;
import com.centralcity.alquimia.domain.exceptions.InsufficientDataException;
import com.centralcity.alquimia.domain.valueobjects.MessageFragment;

import java.util.ArrayList;
import java.util.List;

/** Une los fragmentos posicion por posicion ignorando las palabras vacias (""). */
public final class MessageReconstructor {

    public String reconstruct(List<MessageFragment> fragments) {
        int length = fragments.get(0).size();
        for (MessageFragment fragment : fragments) {
            if (fragment.size() != length) {
                throw new InconsistentDataException("Los fragmentos tienen longitudes distintas ("
                        + length + " y " + fragment.size() + "): no se pueden alinear.");
            }
        }
        List<String> words = new ArrayList<>(length);
        for (int i = 0; i < length; i++) {
            String word = null;
            for (MessageFragment fragment : fragments) {
                String candidate = fragment.words().get(i);
                if (candidate.isEmpty()) {
                    continue;
                }
                if (word == null) {
                    word = candidate;
                } else if (!word.equals(candidate)) {
                    throw new InconsistentDataException("Conflicto en la posicion " + i + ": '"
                            + word + "' contra '" + candidate + "'.");
                }
            }
            if (word == null) {
                throw new InsufficientDataException(
                        "No existen datos suficientes: ningun dispositivo recibio la palabra en la posicion " + i + ".");
            }
            words.add(word);
        }
        return String.join(" ", words);
    }
}
