package com.centralcity.alquimia.domain.models;

import com.centralcity.alquimia.domain.valueobjects.Position;

/** Resultado del procesamiento: ubicacion del laboratorio y mensaje reconstruido. */
public record InterceptionResult(Position location, String message) {
}
