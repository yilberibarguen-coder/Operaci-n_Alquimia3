package com.centralcity.alquimia.adapters.rest.dtos.requests;

import jakarta.validation.constraints.NotNull;

import java.util.List;

/** Reemplazo completo (F4): ambos campos son obligatorios. */
public record DeviceDataRequestDTO(
        @NotNull(message = "es obligatoria") Double distance,
        @NotNull(message = "es obligatorio") List<String> message) {
}
