package com.centralcity.alquimia.adapters.rest.controllers;

import com.centralcity.alquimia.adapters.rest.dtos.requests.DeviceDataRequestDTO;
import com.centralcity.alquimia.adapters.rest.dtos.requests.DeviceReadingRequestDTO;
import com.centralcity.alquimia.adapters.rest.dtos.requests.PartialUpdateRequestDTO;
import com.centralcity.alquimia.adapters.rest.dtos.requests.ProcessRequestDTO;
import com.centralcity.alquimia.adapters.rest.dtos.responses.DeviceReportResponseDTO;
import com.centralcity.alquimia.adapters.rest.dtos.responses.ResultResponseDTO;
import com.centralcity.alquimia.adapters.rest.mappers.AlchemyRestMapper;
import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.ports.in.AlchemyInterceptionPort;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Adaptador de entrada HTTP: solo traduce peticiones a llamadas del puerto y resultados a respuestas. */
@RestController
@RequestMapping("/api/alchemy")
public class AlchemyRestController {

    private final AlchemyInterceptionPort port;

    public AlchemyRestController(AlchemyInterceptionPort port) {
        this.port = port;
    }

    /** F1 */
    @PostMapping("/process")
    public ResultResponseDTO processComplete(@Valid @RequestBody ProcessRequestDTO request) {
        List<DeviceReport> reports = request.devices().stream().map(AlchemyRestMapper::toDomain).toList();
        return AlchemyRestMapper.toResponse(port.processComplete(reports));
    }

    /** F2 */
    @PostMapping("/devices")
    public ResponseEntity<DeviceReportResponseDTO> register(@Valid @RequestBody DeviceReadingRequestDTO request) {
        DeviceReport saved = port.register(AlchemyRestMapper.toDomain(request));
        return ResponseEntity.status(HttpStatus.CREATED).body(AlchemyRestMapper.toResponse(saved));
    }

    /** F3: consulta */
    @GetMapping("/devices")
    public List<DeviceReportResponseDTO> consultAll() {
        return port.consultAll().stream().map(AlchemyRestMapper::toResponse).toList();
    }

    @GetMapping("/devices/{deviceId}")
    public DeviceReportResponseDTO consult(@PathVariable String deviceId) {
        return AlchemyRestMapper.toResponse(port.consult(SurveillanceDevice.fromCode(deviceId)));
    }

    /** F3: procesamiento de lo acumulado */
    @GetMapping("/result")
    public ResultResponseDTO processAccumulated() {
        return AlchemyRestMapper.toResponse(port.processAccumulated());
    }

    /** F4 */
    @PutMapping("/devices/{deviceId}")
    public DeviceReportResponseDTO replace(@PathVariable String deviceId,
                                           @Valid @RequestBody DeviceDataRequestDTO request) {
        SurveillanceDevice device = SurveillanceDevice.fromCode(deviceId);
        return AlchemyRestMapper.toResponse(port.replace(AlchemyRestMapper.toDomain(device, request)));
    }

    /** F5 */
    @PatchMapping("/devices/{deviceId}")
    public DeviceReportResponseDTO updatePartially(@PathVariable String deviceId,
                                                   @RequestBody PartialUpdateRequestDTO request) {
        SurveillanceDevice device = SurveillanceDevice.fromCode(deviceId);
        return AlchemyRestMapper.toResponse(port.updatePartially(device,
                AlchemyRestMapper.toDistance(request.distance()), AlchemyRestMapper.toFragment(request.message())));
    }

    /** F6 */
    @DeleteMapping("/devices/{deviceId}")
    public ResponseEntity<Void> remove(@PathVariable String deviceId) {
        port.remove(SurveillanceDevice.fromCode(deviceId));
        return ResponseEntity.noContent().build();
    }
}
