package com.centralcity.alquimia.domain.services;

import com.centralcity.alquimia.domain.exceptions.InsufficientDataException;
import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.models.InterceptionResult;
import com.centralcity.alquimia.domain.valueobjects.Distance;
import com.centralcity.alquimia.domain.valueobjects.MessageFragment;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Regla comun de F1 y F3: con los tres dispositivos se calcula ubicacion y mensaje; si falta alguno, no hay datos suficientes. */
public final class InterceptionAnalyzer {

    private final LocationCalculator locationCalculator;
    private final MessageReconstructor messageReconstructor;

    public InterceptionAnalyzer(LocationCalculator locationCalculator, MessageReconstructor messageReconstructor) {
        this.locationCalculator = locationCalculator;
        this.messageReconstructor = messageReconstructor;
    }

    public InterceptionResult analyze(Map<SurveillanceDevice, DeviceReport> reports) {
        List<SurveillanceDevice> missing = new ArrayList<>();
        for (SurveillanceDevice device : SurveillanceDevice.values()) {
            if (!reports.containsKey(device)) {
                missing.add(device);
            }
        }
        if (!missing.isEmpty()) {
            throw new InsufficientDataException("No existen datos suficientes: falta la informacion de "
                    + missing.stream().map(SurveillanceDevice::code).toList() + ".");
        }

        Map<SurveillanceDevice, Distance> distances = new EnumMap<>(SurveillanceDevice.class);
        List<MessageFragment> fragments = new ArrayList<>();
        for (SurveillanceDevice device : SurveillanceDevice.values()) {
            DeviceReport report = reports.get(device);
            distances.put(device, report.distance());
            fragments.add(report.fragment());
        }
        return new InterceptionResult(locationCalculator.locate(distances), messageReconstructor.reconstruct(fragments));
    }
}
