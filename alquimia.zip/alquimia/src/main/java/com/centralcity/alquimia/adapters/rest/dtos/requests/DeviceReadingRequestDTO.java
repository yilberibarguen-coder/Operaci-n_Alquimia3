package com.centralcity.alquimia.adapters.rest.dtos.requests;

import jakarta.validation.constraints.NotNull;

import java.util.List;

/** Registro (F2) y elementos de F1: identificacion + distancia + fragmento. */
public record DeviceReadingRequestDTO(
        @NotNull(message = "es obligatorio") String deviceId,
        @NotNull(message = "es obligatoria") Double distance,
        @NotNull(message = "es obligatorio") List<String> message) {
}
