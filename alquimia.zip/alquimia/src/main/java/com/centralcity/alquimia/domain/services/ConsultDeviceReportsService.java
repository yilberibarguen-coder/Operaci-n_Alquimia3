package com.centralcity.alquimia.domain.services;

import com.centralcity.alquimia.domain.exceptions.DeviceNotRegisteredException;
import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.ports.out.DeviceReportRepositoryPort;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;

import java.util.List;

/** F3 (consulta): lo registrado hasta el momento. */
public class ConsultDeviceReportsService {

    private final DeviceReportRepositoryPort repository;

    public ConsultDeviceReportsService(DeviceReportRepositoryPort repository) {
        this.repository = repository;
    }

    public List<DeviceReport> consultAll() {
        return repository.findAll();
    }

    public DeviceReport consult(SurveillanceDevice device) {
        return repository.findByDevice(device).orElseThrow(() -> notRegistered(device));
    }

    static DeviceNotRegisteredException notRegistered(SurveillanceDevice device) {
        return new DeviceNotRegisteredException("El dispositivo '" + device.code() + "' no tiene informacion registrada.");
    }
}
