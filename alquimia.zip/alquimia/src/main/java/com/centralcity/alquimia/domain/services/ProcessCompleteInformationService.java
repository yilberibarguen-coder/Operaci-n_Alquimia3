package com.centralcity.alquimia.domain.services;

import com.centralcity.alquimia.domain.exceptions.InvalidInformationException;
import com.centralcity.alquimia.domain.models.DeviceReport;
import com.centralcity.alquimia.domain.models.InterceptionResult;
import com.centralcity.alquimia.domain.valueobjects.SurveillanceDevice;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** F1: procesa la informacion completa recibida en una sola operacion, sin tocar lo almacenado. */
public class ProcessCompleteInformationService {

    private final InterceptionAnalyzer analyzer;

    public ProcessCompleteInformationService(InterceptionAnalyzer analyzer) {
        this.analyzer = analyzer;
    }

    public InterceptionResult process(List<DeviceReport> reports) {
        if (reports == null || reports.size() != SurveillanceDevice.values().length) {
            throw new InvalidInformationException("Se requiere la informacion de exactamente "
                    + SurveillanceDevice.values().length + " dispositivos.");
        }
        Map<SurveillanceDevice, DeviceReport> byDevice = new EnumMap<>(SurveillanceDevice.class);
        for (DeviceReport report : reports) {
            if (report == null) {
                throw new InvalidInformationException("La informacion de un dispositivo es nula.");
            }
            if (byDevice.put(report.device(), report) != null) {
                throw new InvalidInformationException("Dispositivo repetido: " + report.device().code() + ".");
            }
        }
        return analyzer.analyze(byDevice);
    }
}
