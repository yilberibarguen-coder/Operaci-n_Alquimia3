# Operación Alquimia — Protocolo Savitar

Sistema (Java 17 + Spring Boot 3.5) que recibe la información de tres dispositivos de vigilancia de Central City,
calcula la ubicación del laboratorio de Alchemy por **trilateración** y reconstruye el **mensaje** interceptado.
Aplica **DDD** y **Arquitectura Hexagonal (puertos y adaptadores)**. Todo se guarda **en memoria**: no hay base de datos
ni servicios externos.

## Cómo ejecutarlo (sin instalar nada más que Java 17+)

```bash
./mvnw spring-boot:run        # Linux / macOS / Git Bash
mvnw.cmd spring-boot:run      # Windows (cmd o PowerShell)
./mvnw test                   # pruebas
```

El Maven Wrapper descarga Maven solo la primera vez (necesita internet). La API queda en `http://localhost:8080`.
Si en Linux/macOS `mvnw` no tiene permiso de ejecución: `chmod +x mvnw`.

## Dispositivos (catálogo fijo)

| deviceId         | Nombre             | Posición (X, Y) |
|------------------|--------------------|-----------------|
| `star-labs`      | STAR Labs          | [-500, -200]    |
| `ccpd`           | CCPD               | [100, -100]     |
| `star-satellite` | S.T.A.R. Satellite | [500, 100]      |

El **mensaje** de cada dispositivo es una lista de palabras por posición; `""` = palabra no recibida (se ignora).

## API

| Req. | Método y ruta | Descripción | Respuestas |
|------|---------------|-------------|------------|
| F1 | `POST /api/alchemy/process` | Procesa los 3 dispositivos enviados en el cuerpo (no los guarda) | 200, 400, 422 |
| F2 | `POST /api/alchemy/devices` | Registra un dispositivo | 201, 400, 404 (desconocido), 409 (ya registrado) |
| F3 | `GET /api/alchemy/devices` y `GET /api/alchemy/devices/{deviceId}` | Consulta lo registrado | 200, 404 |
| F3 | `GET /api/alchemy/result` | Procesa lo acumulado | 200, 422 (datos insuficientes / inconsistentes) |
| F4 | `PUT /api/alchemy/devices/{deviceId}` | Reemplazo completo (`distance` y `message` obligatorios) | 200, 400, 404 |
| F5 | `PATCH /api/alchemy/devices/{deviceId}` | Actualización parcial (`distance` y/o `message`) | 200, 400, 404 |
| F6 | `DELETE /api/alchemy/devices/{deviceId}` | Elimina un dispositivo | 204, 404 |

Los errores tienen siempre la forma `{ "timestamp", "status", "code", "message" }`.

### Ejemplos (laboratorio real en (100, 200))

```bash
# F2 - registrar (en cualquier orden)
curl -X POST localhost:8080/api/alchemy/devices -H 'Content-Type: application/json' \
  -d '{"deviceId":"star-labs","distance":721.11,"message":["este","","un",""]}'
curl -X POST localhost:8080/api/alchemy/devices -H 'Content-Type: application/json' \
  -d '{"deviceId":"ccpd","distance":300,"message":["","es","","mensaje"]}'

# F3 - con 2 dispositivos: 422 INSUFFICIENT_DATA
curl localhost:8080/api/alchemy/result

curl -X POST localhost:8080/api/alchemy/devices -H 'Content-Type: application/json' \
  -d '{"deviceId":"star-satellite","distance":412.31,"message":["este","","","mensaje"]}'
curl localhost:8080/api/alchemy/result
# -> {"location":{"x":100.0,"y":200.0},"message":"este es un mensaje"}

# F5 - solo la distancia (el mensaje se conserva)
curl -X PATCH localhost:8080/api/alchemy/devices/ccpd -H 'Content-Type: application/json' -d '{"distance":300.5}'

# F4 - reemplazo completo
curl -X PUT localhost:8080/api/alchemy/devices/ccpd -H 'Content-Type: application/json' \
  -d '{"distance":300,"message":["","es","un","mensaje"]}'

# F6 - eliminar
curl -X DELETE localhost:8080/api/alchemy/devices/ccpd

# F1 - todo en una sola petición
curl -X POST localhost:8080/api/alchemy/process -H 'Content-Type: application/json' -d '{"devices":[
 {"deviceId":"star-labs","distance":721.11,"message":["este","","un",""]},
 {"deviceId":"ccpd","distance":300,"message":["","es","","mensaje"]},
 {"deviceId":"star-satellite","distance":412.31,"message":["este","","","mensaje"]}]}'
```

## Arquitectura

```
com.centralcity.alquimia
├── domain                      <- NO depende de Spring, HTTP ni de la forma de almacenar
│   ├── models                  DeviceReport (info de un dispositivo, inmutable), InterceptionResult
│   ├── valueobjects            SurveillanceDevice (catálogo), Distance, Position, MessageFragment (validan sus invariantes)
│   ├── exceptions              DomainException + errores de negocio con código estable
│   ├── ports
│   │   ├── in                  AlchemyInterceptionPort  (lo que el sistema ofrece: F1-F6)
│   │   └── out                 DeviceReportRepositoryPort (lo que el sistema necesita: guardar en algún lado)
│   └── services                un servicio por caso de uso + LocationCalculator, MessageReconstructor, InterceptionAnalyzer
├── adapters
│   ├── rest                    controlador, DTOs, mapper y GlobalExceptionHandler (HTTP <-> dominio)
│   ├── persistence/memory      InMemoryDeviceReportRepositoryAdapter (ConcurrentSkipListMap)
│   └── useCases                AlchemyUseCaseImpl: implementa el puerto de entrada y delega en los servicios
└── infrastructure/config       BeanConfiguration: único sitio donde Spring "arma" los servicios del dominio
```

La dependencia siempre apunta hacia el dominio: `adapters -> domain`. Cambiar HTTP por consola, o la memoria por
una base de datos, no toca el dominio.

## Decisiones de diseño (para sustentar)

- **Trilateración**: se restan las ecuaciones de los círculos para obtener un sistema lineal 2x2 (regla de Cramer).
  Después se verifica que el punto cumpla las tres distancias con tolerancia de 1.0 (`LocationCalculator.TOLERANCE`);
  si no, `INCONSISTENT_DATA`. El resultado se redondea a 2 decimales.
- **Reconstrucción del mensaje**: los fragmentos se alinean por posición y se ignoran los `""`. Si dos dispositivos dan
  palabras distintas en la misma posición o tienen distinta longitud -> `INCONSISTENT_DATA`; si nadie recibió una
  posición -> `INSUFFICIENT_DATA`.
- **"Datos suficientes"** = están registrados los **tres** dispositivos y el mensaje queda completo.
- **Registro vs. reemplazo**: `POST` sobre un dispositivo ya registrado da 409 (para eso existen PUT y PATCH);
  `PUT`, `PATCH` y `DELETE` sobre uno no registrado dan 404.
- **Reemplazo vs. parcial**: `PUT` exige distancia y mensaje y sustituye todo; `PATCH` solo modifica lo recibido
  y debe traer al menos un campo.
- **Consistencia**: `DeviceReport` es inmutable (cada cambio crea una versión nueva) y `AlchemyUseCaseImpl` sincroniza
  sus operaciones, así registrar/actualizar/eliminar/procesar son atómicos en un proceso con estado en memoria.
- **Validación en dos niveles**: Bean Validation en los DTOs (campos obligatorios, forma de la petición) y los
  *value objects* del dominio (distancia finita y >= 0, fragmento no vacío, sin nulos, dispositivo conocido).
- **Dominio sin anotaciones de Spring**: los servicios se registran como beans en `BeanConfiguration`.
